Manual de latex:
                http://en.wikibooks.org/wiki/LaTeX
